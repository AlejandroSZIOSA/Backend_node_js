"use strict";
// CONFIGURE END POINTS 
const express = require('express'); //END-POINT TOOL IMPORT
const { body } = require ('express-validator'); //VALIDATION TOOL IMPORT (MIDDLEWARE)
const eventsController = require('../controller/events'); //CONTROLLER IMPORT
//13.4 
const isAuth = require('../middleware/is-auth'); //MIDDLEWARE IMPORT

const router = express.Router();//INITIALISATION EXPRESS-SERVICE

// END-POINTS

//1- GET /events/all -> show all events
router.get('/all',eventsController.getEvents); 

//2- POST /publishevents/postevent + VALIDATION TITLE 
//13.5 Add isAuth as parameter + AUTHORIZATION
router.post('/postevent',isAuth, [body('title')//body validation (MIDDLEWARE)
        .trim()// Method that remove spaces in a string
        .isLength({min:1,max:35}) //Validate title length event
],eventsController.createPost);

//7.0 -  GET /publishevent/id:'event_Id'
router.get('/:eventId', eventsController.getEvent); // 7.2 - a path + controller 

//8.0- PUT /publishevents/id:'event_Id' -> "EDIT/UPDATE/REPLACE"  request have a body
router.put('/:eventId',[body('title').trim()
        .isLength({min:1,max:35})],eventsController.editEvent);//8.4 Add a second param

// 9.0- DELETE /publishevents/id:'event_Id'
router.delete('/:eventId',eventsController.deleteEvent); //9.3

module.exports = router;
