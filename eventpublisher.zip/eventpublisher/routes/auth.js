const express = require ('express');
// 10.5 Adding Validation

const {body} = require('express-validator/check');

const User = require('../models/user'); //inports

const authController = require('../controller/auth'); // 10 .6 inport controller 
const { route } = require('./events');

const router = express.Router();
// 10.1     Authentication "create a user" 

// 10.6 -validation [] midelwhere , asinc
router.put('/signup',[body('email')
    .isEmail()
    .withMessage('Enter a valid E- mail')
    .custom((value,{req}) => { //promise
        return User.findOne({email:value}).then(userDoc =>{
            if(userDoc){
                return Promise.reject('E-mail alredy exist');
            }
        });
    })
    .normalizeEmail(), //check a valid email format
    body('password')
    .trim() //remove blank spaces
    .isLength({min: 5}),
    body('alias')
    .trim()
    .not()
    .isEmpty()
], authController.signup
);
// 12.0 AUTH LOGIN A USER 

//12.1 Adding controller .login
router.post('/login', authController.login);//12.6 Add controller as params

module.exports = router; // export router