// 13.0 ADDING AUTHORIZATION (MIDDLEWARE)
const jwt = require('jsonwebtoken'); //import Token-TOOL

/* Creating a middleware
middleware runs on the server  side
middleware are functions in the backend
middleware used for protect router
middleware Autorization */

//A function that exports
module.exports = (req, res , next) => {
    // 13.2 a header can be defined in the front end app to
    const authHeader = req.get('Authorization');
    if(!authHeader){
        const error = new Error('Not authenticated')
        error.statusCode = 401;
        throw error;
    }
    const token = authHeader.split(' ')[1]; // this is the Token
    let decodedToken; //decode the token
    // 13.3 - Validating Used token
    try{
        //check if token is valid
        decodedToken = jwt.verify(token, 'mytestpasword') 
    } catch (err){
        err.statusCode = 500;
        throw err; // Send a message to the browser
    }
    //If not match
    if(!decodedToken){
        const error = new Error('Not authenticated');
        error.statusCode = 401;
        throw error;//Send a message to the browser
    }
    req.userId = decodedToken.userId; // this get authorisation
    next(); //continue
};