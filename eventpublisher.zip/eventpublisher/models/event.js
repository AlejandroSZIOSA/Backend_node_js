//5.0 - CREATING AN EVENT MODEL
// Schemmas are used to define data structure in DB :)
const mongoose = require('mongoose'); //4.03 IMPORT MONGOSSE
const Schema = mongoose.Schema; //4.04

//5.1 CREATING AN SCHEMA FORM OF THE INFORMATION
const eventSchema = new Schema(
        {
            //Property "require" is a mandatory field
            title:{
                type: String,
                require: true // Included for querys result by default
            },
            description:{
                type: Object,
                require:String
            },
            organizer:{
                type: String,
                require: true
            },
        },
        {timestamps:true} // create publish or edite date of the object (automatic)
);
//export the model schema
//"Event" now is on Mongo DB 
module.exports = mongoose.model('Event', eventSchema); 