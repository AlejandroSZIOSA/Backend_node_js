const mongoose = require ('mongoose');
const Schema = mongoose.Schema; // Define User Schema

// 10.0   Create a User + Authentication
const userShema = new Schema({
    email:{
        type: String,
        require:true 
    },
    password:{
        type: String,
        require: true
    },
    alias: {
        type: String,
        require: true
    },
    status:{
        type: String,
        default:'I am a new User'
    },
    /* events:[eventId] */
});
module.exports = mongoose.model('User', userShema) //to the DB