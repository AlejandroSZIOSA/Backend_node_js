const {validationResult} = require('express-validator') //VALIDATION-TOOL IMPORT
const Event = require('../models/event'); // EVENT-MODEL IMPORT
const { post } = require('../routes/events');

// 1- GET EVENTS... sending information response  :) JSON FORM
exports.getEvents = (req, res, next) => {
    /* 
    req = request
    res = response
    next = can execute more functions
    only res -> can be used to get some object via localhost to 
    */
    //-7.3 find is Asinc
    Event.find()
        .then(events => {res.status(200)
            .json({message: 'Fetched All Events',events:events});
        })
        .catch(err => {
            if(!err.statusCode){
                err.statusCode = 500;
        }
        next(err);
        });
    //console.log("In response");
};

// 2.0- POST -> CREATE AN EVENT (asinc)
exports.createPost = (req, res,next) => {
    //4.0- VALIDATION OF ERRORS
    const errors = validationResult(req); //validation take request as parameter
        if(!errors.isEmpty()){
            const error = new Error('Data length incorrect / [title] = Between 1-15 characters');
            error.statusCode = 422; //show error status code in the "CONSOLE"
            //throw = exeptions
            throw error;//show error message in the "BROWSER" and "terminate the program"
        }
    const title = req.body.title; // declare a body
    const organizer= req.body.organizer;
    const description = req.body.description; //declare a body 
    //6.0- Create an event in DB 
    const event = new Event({
            title: title,
            organizer:organizer,
            //content: content
            description: description, // indicate as object :)  
    });
    //6.1 Saving in the DB
    event.save()
        .then(result => {
            console.log(result)
            //response here
            res.status(201).json( {
                message:'Event has been successfully created!',
                event:result     
            });
        })
    //6.2 Error handling
    .catch(err => {
        if(!err.statusCode) {
            err.statusCode = 500; //edit status code
        }
        next(err); //goes to the next error handling in expess middelware
        //console.log(err);
    });
};
//7.1 GET A SIGLE EVENT BY ID
exports.getEvent = (req,res,next) => {
    const eventId = req.params.eventId; // Get the event id from the client
    Event.findById(eventId) //MONGOSSE METHOD
    // error handling
    .then(event => {
        if (!event){
            const error = new Error ('Could not find the Event.');
            error.statusCode = 404; //not found Statuscode
            throw error;
            /* if "throw" cast is inside a "then" then the 
            next action will be pass the error to the "catch" block */
        }
        //StatusCode 200 = Sucess
        res.status(200).json({message: 'Single Event fetched', event:event});//No problem
    })
    .catch(err => {
        if (!err.statusCode) {
            err.statusCode = 500; // Editing the new error
        }
        next(err);
    })
};
// -8.1 Function edit an event
exports.editEvent = (req,res,next) => {
    const eventId = req.params.eventId; // extract the information
    //  -8.2 errors validation
    const errors = validationResult(req); //validation take request as parameter
        if(!errors.isEmpty()){
            const error = new Error('Data length incorrect');
            error.statusCode = 422; // define error status code 
            throw error; // terminate the function
        }
    const title = req.body.title;//extract the information //problem fix it!
    const organizer = req.body.organizer; // fixed!
    const description = req.body.description;//extract the information
    //8.3 Asinc function search in DB 
    Event.findById(eventId) 
    .then(event => {
        if (!event){
            const error = new Error ('Could not find the Event.');
            error.statusCode = 404;
            throw error; // 7.1 - goint to the next function
        }
        event.title = title; // problem fixed!
        event.organizer= organizer;
        event.description = description;
        return event.save(); // save New information in DB
    })
    .then(result =>{
        res.status(200).json({message: 'Event has been Edited.', post:result})
    })
    .catch(err => {
        if (!err.statusCode) {
            err.statusCode = 500;
        }
        next(err);
    });
}
// 9.1 DELETE
exports.deleteEvent = (req,res,next) => {
    const eventId = req.params.eventId; // extract id
    Event.findById(eventId) // find the event
        //9.2
        .then(event => {
            //Check if Event exist
            if (!event){
                const error = new Error ('Could not find the Event.');
                error.statusCode = 404;
                throw error; // 7.1 - goint to the next function
            }
            return Event.findByIdAndRemove(eventId);
        })
        .then(result=> {
            console.log(result);
            res.status(200).json({message:'Event has been deleted.'})
        })
        .catch(err => {
            if (!err.statusCode) {
                err.statusCode = 500;
            }
            next(err);
        });
};