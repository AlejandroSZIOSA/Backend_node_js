const {validationResult} = require('express-validator/check');

//11.0 Encrypt pasword
const bcrypt = require('bcryptjs')// Import bcryptjs - encript pass
const User = require ('../models/user'); //10.4 import
const jwt = require('jsonwebtoken'); // import json tocken

exports.signup = (req, res, next) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        const error = new Error ('Validation Failed.');
        error.statusCode = 422;
        error.data = errors.array();
        throw error;
    }
    const email = req.body.email;
    const alias = req.body.alias;
    const password = req.body.password; //extract password
    bcrypt
        .hash(password,12) //length 12 + Hashing The User password
        .then(hashedPw => {
            const user = new User({
                email: email,
                password: hashedPw,
                alias: alias
            });
        return user.save();//Save User in DB
        })
        .then( result => {
        // sending a response 
        res.status(201).json({message:'User Created!',userId: result._id});
        }) 
    .catch(err=>{
        if (!err.statusCode) {
            err.statusCode = 500;
        }
        next(err);
    })
};
//12.2 LOGIC , RETRIVE USER ,AUTHENTICATION, A function
exports.login = (req,res, next) => {
    //Logic
    const email = req.body.email; // retrive email
    const password =req.body.password //retrive pasword
    let loadedUser; // store the User information
    //If User exist
    User.findOne({email: email}) //Can fail or Sucess
        .then( user => {
            // if not find user
            if(!user){
                const error =new Error('User not found')
                error.statusCode =401; // un-authenticated code
                throw error; // throw error to the browser
            }
            // else 
            loadedUser = user; // 12.3 - validating the password
            
            /* Compare login password with the stored password
            Compare method returns a Promise */
            return bcrypt.compare(password,user.password);
        })
        .then(isEqual =>{
                if (!isEqual){
                    const error = new Error('Wrong password!');
                    error.statusCode = 400; // not found code
                    throw error;
                }
               /*  12.4- Creatin a token :)
                Jwt imported . have own methods
                Token store in the client */
                
                const token = jwt.sign({
                    email: loadedUser.email, 
                    userId: loadedUser._id.toString()
                    },'mytestpasword', // It is a test password
                    {expiresIn: '1h'}// Security. 
                );
                //12.5- response with the token .. must be created
                res.status(200).json({
                    token: token,
                    userId: loadedUser._id.toString()
                });
        })
        .catch(err =>{
            if(err.statusCode){

                err.statusCode = 500;
            }
            next(err);

        }
        );
};
