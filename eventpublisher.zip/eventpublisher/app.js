const express = require('express'); // 1.0 - CALLING EXPRESS MODUL

const bodyParser = require('body-parser'); // 1.2 TRANSFORM TO JSON DATA

const mongoose = require('mongoose'); // IMPORT MONGOSSE MODUL(4.0-MONGO DB CONECTION)

const feedRoutes = require('./routes/events'); // create a conection
const authRoutes = require('./routes/auth'); // 10.2

const app = express(); //1.1

app.use(bodyParser.json()); //2.1 parse Json data 

//3.0 - ALLOWING ACCES CONTROL (OPTIONS) FROM BROWSER
app.use((req, res,next) => {
    res.setHeader('Access-Control-Allow-Origin','*');
    res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,PATCH,DELETE');
    res.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization');  
    next(); // pass control to the next handler    
} );
app.use('/publishevents',feedRoutes);
app.use('/auth',authRoutes); // 10.3

//-6.3 Errors Handling function
app.use ((error, req,res,next)=> {
    console.log(error)
    const status = error.statusCode || 500; //Extracting error information
    const message = error.message;//Extracting error information
    //10.5 error auth
    const data = error.data;
    res.status(status).json({message: message, data:data}) //return a Json object
    // 1-res.status(status).json({message: message}) sin auth //optional
});

//4.01-CONECT TO THE DB MONGO DB 
mongoose.connect('mongodb+srv://Gabriel:<password>@bookdbtest1.nlmcd74.mongodb.net/?retryWrites=true&w=majority'
)
.then(result => {
    app.listen(8080); //4.02-conection to a localhost port
})
.catch(err => console.log(err)); // error
